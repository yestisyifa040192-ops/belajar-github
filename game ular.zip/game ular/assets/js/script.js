const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const menu = document.getElementById("menu");
const scoreDiv = document.getElementById("score");
const scoreValue = document.getElementById("scoreValue");
const highscoreText = document.getElementById("highscoreValue");

const box = 20;
let snake, direction, food, game, score, isPaused = false, isStarted = false;
let highscore = localStorage.getItem("snakeHighscore") ? parseInt(localStorage.getItem("snakeHighscore")) : 0;
highscoreText.textContent = highscore;

function initGame() {
    snake = [{ x: 10 * box, y: 10 * box }];
    direction = "UP";
    score = 0;
    scoreValue.textContent = score;
    food = randomFood();
    clearInterval(game);
    game = setInterval(draw, 250);
}

function randomFood() {
    return {
    x: Math.floor(Math.random() * (canvas.width / box)) * box,
    y: Math.floor(Math.random() * (canvas.height / box)) * box
    };
}

function draw() {
    if (isPaused || !isStarted) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Makanan
    ctx.fillStyle = "#ff1744";
    ctx.shadowColor = "#ff1744";
    ctx.shadowBlur = 10;
    ctx.fillRect(food.x, food.y, box, box);

    // Ular
    ctx.shadowBlur = 0;
    for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = i === 0 ? "#00b0ff" : "#4caf50";
        ctx.fillRect(snake[i].x, snake[i].y, box, box);
        ctx.strokeStyle = "white";
        ctx.strokeRect(snake[i].x, snake[i].y, box, box);
    }

    let head = { ...snake[0] };
    if (direction === "LEFT") head.x -= box;
    if (direction === "UP") head.y -= box;
    if (direction === "RIGHT") head.x += box;
    if (direction === "DOWN") head.y += box;

    if (head.x === food.x && head.y === food.y) {
        score++;
        scoreValue.textContent = score;
        food = randomFood();
    } else {
        snake.pop();
    }

    // tabrakan
    if (
        head.x < 0 || head.y < 0 ||
        head.x >= canvas.width || head.y >= canvas.height ||
        snake.some(p => p.x === head.x && p.y === head.y)
    ) {
        clearInterval(game);
        checkHighscore();
        alert('💀 Game Over!\nSkor kamu: ${score}');
        resetToMenu();
        return;
    }

    snake.unshift(head);
}

function checkHighscore() {
    if (score > highscore) {
    highscore = score;
    localStorage.setItem("snakeHighscore", highscore);
    highscoreText.textContent = highscore;
    }
}

function resetToMenu() {
    canvas.style.display = "none";
    pauseBtn.style.display = "none";
    scoreDiv.style.display = "none";
    menu.style.display = "block";
    highscoreText.textContent = highscore;
    isStarted = false;
}

document.addEventListener("keydown", e => {
    if (!isStarted) return;

    if ((e.key === "ArrowLeft" || e.key === "a") && direction !== "RIGHT") direction = "LEFT";
    else if ((e.key === "ArrowUp" || e.key === "w") && direction !== "DOWN") direction = "UP";
    else if ((e.key === "ArrowRight" || e.key === "d") && direction !== "LEFT") direction = "RIGHT";
    else if ((e.key === "ArrowDown" || e.key === "s") && direction !== "UP") direction = "DOWN";

    if (e.key === " ") togglePause();
});

startBtn.addEventListener("click", () => {
    menu.style.display = "none";
    canvas.style.display = "block";
    pauseBtn.style.display = "block";
    scoreDiv.style.display = "block";
    isStarted = true;
    isPaused = false;
    initGame();
});

pauseBtn.addEventListener("click", togglePause);

function togglePause() {
    if (!isStarted) return;
    isPaused = !isPaused;
    pauseBtn.textContent = isPaused ? "Resume" : "Pause";
}